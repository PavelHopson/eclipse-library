# Редактируемый ролик Tesseract / Codex

Учебный пример Eclipse Library, 11.10.2026. Снимок публичной галереи Koboyo.
Итог v2: 1280×800, 30 fps, 16 секунд, H.264 + AAC. Запись интерфейса: 15 fps.
Титры RU/EN — авторский текст, не распознанная речь. Звук — оригинальная
процедурная атмосфера; лицензия на эту дорожку: CC0 1.0 Universal
(https://creativecommons.org/publicdomain/zero/1.0/). Это не звук интерфейса.
Inter — SIL OFL, персонажи Koboyo — Kamran Ahmed, MIT; тексты лицензий приложены.

## Повторное редактирование

Установите официальный Tesseract 0.3.1 отдельно; движок в архив не включён.
Откройте папку в Codex и передайте prompt.md. CLI поддерживает следующие действия:

```text
tsrct project checkout --project project-v2.tsrct --output edit.json
tsrct project commit --project project-v2.tsrct --file edit.json
tsrct preview --project project-v2.tsrct --time 1 --output frame.png
tsrct export --project project-v2.tsrct --output revised.mp4 --resolution 1080p --fps 30 --json
```

Работайте с копией проекта. В этом CLI 1080p — масштаб экспорта, не обещание
1920×1080: обязательно проверьте фактический размер через ffprobe.

В v2 заменён первый заголовок на «58 вариантов. Выберите своего.» / «58 variants.
Find your companion.», звук поднят на 12 dB. Видеофайл подготовлен для конвертера:
выполнено SDR-преобразование full→limited и отдельный remux с H.264/MP4 BT.709 metadata. Не применять
это к HDR и неизвестному профилю. Старый проект и preview сохранены.

## Пределы проверки

Tesseract: рендер, RU/EN, сохранение и повторное открытие проверяются отдельно
в verification.json. Аудио: измерения выполнены, прослушивание человеком требуется.
Adobe-проекты созданы отдельно локально и в этот ZIP не включены: переносимость
их медиассылок не проверена. Premiere/After Effects здесь не запускались. AEP экспериментален: возможны отличия шрифта, Box Text и тайминга.
Наличие файлов не подтверждает Adobe round-trip. Для Adobe может потребоваться
установка Inter из его официального источника с сохранением OFL.

Частных персонажей, личных файлов и бинарников Tesseract в этом архиве нет.

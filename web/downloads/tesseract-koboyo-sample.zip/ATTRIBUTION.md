# Sources

Screen recording: public Eclipse Library Koboyo gallery, captured 2026-10-11. Mascots: Kamran Ahmed, Koboyo/page-mascot, MIT.
Font: Inter, Google Fonts, SIL OFL 1.1; license retained.
Audio: original local procedural two-note atmosphere created for this pilot; no external recordings. Not voiceover, not source UI sound.
Captions are authored marketing overlays, not a transcription.
